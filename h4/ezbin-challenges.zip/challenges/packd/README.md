packd - what's the password? What's the flag?
Copyright 2024 Tero Karvinen https://TeroKarvinen.com

	$ ./packd
	What's the password?

